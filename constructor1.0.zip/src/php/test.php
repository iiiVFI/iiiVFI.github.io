<?php
$email = $_POST['user_email'];
$phone = $_POST['user_tel'];
echo 'Сработало: <br>'. $email .'<br>' . $phone;
?>